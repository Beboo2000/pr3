
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.IntStream;

/**
 *
 * @author sa
 */
public class character {

    public static void main(String[] args) {

        try {
            Map<Character, Integer> count
                    = Files
                            .lines(Paths.get("textfile.txt"))
                            .flatMap(line -> IntStream.range(0, line.length()).mapToObj(line::charAt))
                            .filter(Character::isLetter)
                            .map(Character::toLowerCase)
                            .collect(TreeMap::new, (m, c) -> m.merge(c, 1, Integer::sum), Map::putAll);

            count.forEach((letter, c) -> System.out.println(letter + ": " + c));
        } catch (IOException e) {
            System.err.println("Error :(");
        }

    }
}
