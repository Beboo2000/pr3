
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author sa
 */
public class Upgrade extends Application {

    List<Student> students;
    ListView<Student> lv_students;
    String userName, password;
    Label label_Welcome, label_userName, label_password;
    TextField tf_userName, tf_password;
    Button btn_sign, btn_exit, btn_add, btn_View;
    HBox hb_userName, hb_password, hb_buttons;
    Scene scene;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {

        students = new ArrayList<>();
        lv_students = new ListView();
        showWelcomePage(primaryStage);

    }

    private void showWelcomePage(Stage primaryStage) throws FileNotFoundException {

        File file = new File("password.txt");
        try {
            PrintWriter pw = new PrintWriter(file);
            pw.println("bahaa");
            pw.println(getMD5("123456"));
            pw.flush();
        } catch (IOException ex) {
            System.err.println("Error");
        }

        Scanner scanner = new Scanner(file);
        userName = scanner.nextLine();
        password = scanner.nextLine();

        label_Welcome = new Label("Welcome");
        label_Welcome.setId("label_Welcome");

        label_userName = new Label("User Name");
        tf_userName = new TextField();
        hb_userName = new HBox(20, label_userName, tf_userName);
        label_password = new Label("Password");
        tf_password = new TextField();
        hb_password = new HBox(28, label_password, tf_password);

        btn_sign = new Button("Sign");
        btn_exit = new Button("Exit");
        hb_buttons = new HBox(10, btn_sign, btn_exit);
        hb_buttons.setAlignment(Pos.BASELINE_RIGHT);

        btn_sign.setOnAction(e -> {
            if (tf_userName.getText().equals(userName) && getMD5(tf_password.getText()).equals(password)) {
                showOptionsPage(primaryStage);
            }
        });

        btn_exit.setOnAction(e -> {
            primaryStage.close();
        });

        GridPane gridPane = new GridPane();
        gridPane.add(label_Welcome, 0, 0);
        gridPane.add(hb_userName, 0, 1);
        gridPane.add(hb_password, 0, 2);
        gridPane.add(hb_buttons, 0, 3);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setVgap(20);

        scene = new Scene(gridPane, 400, 200);
        scene.getStylesheets().add("Style.css");
        primaryStage.setTitle("Login Page");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static String getMD5(String password) {
        String MD5 = "";
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");

            byte[] messageDigest = md.digest(password.getBytes());

            BigInteger bigInteger = new BigInteger(1, messageDigest);

            MD5 = bigInteger.toString(16);
            while (MD5.length() < 32) {
                MD5 = "0" + MD5;
            }

        } catch (NoSuchAlgorithmException e) {
            System.err.println("Error");
        }
        return MD5;

    }

    private void showOptionsPage(Stage primaryStage) {
        btn_add = new Button("Add Student");
        btn_View = new Button("View Students");

        btn_add.setOnAction(e -> {
            showAddPage(primaryStage);
        });

        btn_View.setOnAction(e -> {
            showViewPage(primaryStage);
        });

        VBox vb_btns = new VBox(20, btn_add, btn_View);
        vb_btns.setAlignment(Pos.CENTER);

        scene = new Scene(vb_btns, 400, 200);
        scene.getStylesheets().add("Style.css");
        primaryStage.setTitle("Options Page");
        primaryStage.setScene(scene);
    }

    private void showAddPage(Stage primaryStage) {
        Label label_std_data = new Label("Student Data");
        label_std_data.setId("label_std_data");
        label_std_data.setAlignment(Pos.CENTER_LEFT);

        Label label_std_iD = new Label("Id:");
        TextField tf_std_id = new TextField();
        HBox hb_std_id = new HBox(35, label_std_iD, tf_std_id);

        Label label_std_name = new Label("Name:");
        TextField tf_std_name = new TextField();
        HBox hb_std_name = new HBox(12, label_std_name, tf_std_name);

        Label label_std_major = new Label("Major:");
        TextField tf_std_major = new TextField();
        HBox hb_std_major = new HBox(13, label_std_major, tf_std_major);

        Label label_std_grade = new Label("Grade:");
        TextField tf_std_grade = new TextField();
        HBox hb_std_grade = new HBox(12, label_std_grade, tf_std_grade);

        Button btn_std_add = new Button("Add");
        Button btn_std_reset = new Button("Reset");
        Button btn_std_exit = new Button("Exit");

        btn_std_reset.setOnAction(e -> {
            tf_std_id.setText("");
            tf_std_name.setText("");
            tf_std_major.setText("");
            tf_std_grade.setText("");
        });

        btn_std_exit.setOnAction(e -> {
            showOptionsPage(primaryStage);
        });

        HBox hb_std_btns = new HBox(5, btn_std_add, btn_std_reset, btn_std_exit);
        hb_std_btns.setAlignment(Pos.CENTER_RIGHT);

        VBox vb_fileds = new VBox(15, label_std_data, hb_std_id, hb_std_name, hb_std_major, hb_std_grade, hb_std_btns);

        lv_students.setPrefWidth(400);

        btn_std_add.setOnAction(e -> {
            try {
                Student newStudent = new Student(
                        Integer.parseInt(tf_std_id.getText()),
                        tf_std_name.getText(),
                        tf_std_major.getText(),
                        Double.parseDouble(tf_std_grade.getText())
                );
                students.add(newStudent);
                lv_students.getItems().add(newStudent);
                tf_std_id.setText("");
                tf_std_name.setText("");
                tf_std_major.setText("");
                tf_std_grade.setText("");
            } catch (Exception exception) {
            }
        });

        HBox hb_view = new HBox(30, vb_fileds, lv_students);
        hb_view.setPadding(new Insets(20));

        scene = new Scene(hb_view, 700, 400);
        scene.getStylesheets().add("Style.css");
        primaryStage.setTitle("Student Entry Page");
        primaryStage.setScene(scene);
    }

    private void showViewPage(Stage primaryStage) {
        Button btn_view_sort_by_name = new Button("Sort by name");
        Button btn_view_sort_by_grade = new Button("Sort by grade");
        Button btn_view_filter_by_grade = new Button("filter by grade");
        Button btn_view_avg = new Button("Calculate average");
        Button btn_view_group_by_major = new Button("Group by major");
        Button btn_view_exit = new Button("Exit");
        Label label_avg = new Label();
        label_avg.setId("label_avg");

        btn_view_sort_by_name.setOnAction(e -> {
            sortStudentsByName();
        });

        btn_view_sort_by_grade.setOnAction(e -> {
            sortStudentsByGrade();
        });

        btn_view_filter_by_grade.setOnAction(e -> {
            filterStudentsByGrade();
        });
        btn_view_avg.setOnAction(e -> {
            calcAvg(label_avg);
        });
        btn_view_group_by_major.setOnAction(e -> {
            groupByMajor(primaryStage);
        });
        btn_view_exit.setOnAction(e -> {
            showOptionsPage(primaryStage);
        });

        HBox hb_fileds_1 = new HBox(20, btn_view_sort_by_name, btn_view_sort_by_grade);
        HBox hb_fileds_2 = new HBox(20, btn_view_filter_by_grade, btn_view_avg, label_avg);
        HBox hb_fileds_3 = new HBox(20, btn_view_group_by_major, btn_view_exit);

        VBox vb_view = new VBox(10, lv_students, hb_fileds_1, hb_fileds_2, hb_fileds_3);
        vb_view.setAlignment(Pos.CENTER);
        vb_view.setPadding(new Insets(20));

        scene = new Scene(vb_view, 500, 500);
        scene.getStylesheets().add("Style.css");
        primaryStage.setTitle("Student Entry Page");
        primaryStage.setScene(scene);
    }

    private void sortStudentsByName() {
        lv_students.getItems().setAll(
                students.stream()
                        .sorted((s1, s2) -> s1.getName().compareToIgnoreCase(s2.getName()))
                        .collect(Collectors.toList())
        );
    }

    private void sortStudentsByGrade() {
        lv_students.getItems().setAll(
                students.stream()
                        .sorted((Student o1, Student o2) -> o1.getGrade() > o2.getGrade() ? -1 : 1)
                        .collect(Collectors.toList())
        );
    }

    private void filterStudentsByGrade() {
        lv_students.getItems().setAll(
                students.stream()
                        .filter((Student t) -> t.getGrade() >= 80 && t.getGrade() <= 90)
                        .sorted((Student o1, Student o2) -> o1.getGrade() > o2.getGrade() ? -1 : 1)
                        .collect(Collectors.toList())
        );
    }

    private void calcAvg(Label label_avg) {
        double avg = students.stream()
                .mapToDouble((Student t) -> t.getGrade())
                .average()
                .getAsDouble();
        label_avg.setText("Average: " + Math.round(avg * 100) / 100.0);
    }

    private void groupByMajor(Stage primaryStage) {
        lv_students.getItems().clear();
        students.stream()
                .collect(Collectors.groupingBy(Student::getMajor))
                .forEach((student, major)
                        -> major.forEach(e -> lv_students.getItems().add(e))
                );
    }

}
