
/**
 *
 * @author sa
 */
public class Student implements Comparable<Student> {

    private int id;
    private String name;
    private String major;
    private double grade;

    public Student() {
    }

    public Student(int id, String name, String major, double grade) {
        this.id = id;
        this.name = name;
        this.major = major;
        this.grade = grade;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    @Override
    public String toString() {
        String format = "";
        try {
            format = String.format("%-" + (25 - String.valueOf(id).length()) + "d"
                    + "%-" + (25 - name.length()) + "s"
                    + "%-" + (50 - major.length()) + "s"
                    + "%-2.2f",
                    id, name, major, grade
            );
        } catch (Exception exception) {
        }
        return format;
    }

    @Override
    public int compareTo(Student s2) {
        return this.grade >= s2.grade ? -1 : 1;
    }

}
