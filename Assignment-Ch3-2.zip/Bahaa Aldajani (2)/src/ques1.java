
import java.util.function.IntConsumer;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

/**
 *
 * @author sa
 */
public class lambda {

    public static void main(String[] args) {


        IntConsumer intConsumer = v -> System.out.printf("%d ", v);
        intConsumer.accept(55);
        System.out.println("");

        UnaryOperator<String> toUpperCase = String::toUpperCase;
        System.out.println(toUpperCase.apply("string to be in upper case."));

        
        Supplier<String> supplier = () -> "Welcome to lambdas!";
        System.out.println(supplier.get());

        
        UnaryOperator<Integer> cube = number -> (int) Math.pow(number, 3);
        System.out.println(cube.apply(5));

    }

}
