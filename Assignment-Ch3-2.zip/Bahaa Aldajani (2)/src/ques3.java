

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author sa
 */
public class list {

    public static void main(String[] args) {

        Employee[] employees = {
            new Employee(1, "bahaa", "IT", 1201),
            new Employee(2, "beboo", "Sales", 959.6),
            new Employee(4, "sam", "Marketing", 1111),
            new Employee(5, "ahmed", "IT", 1200),
            new Employee(7, "abd", "Sales", 1008.5)
        };
        List<Employee> listEmployees = Arrays.asList(employees);

        listEmployees.stream()
        .filter(e -> e.getSalary() >= 800 && e.getSalary() < 1200)

        .map(e -> new Employee(e.getId(), e.getName(), e.getDepartment(), e.getSalary() * 1.02))
                
               
                .collect(Collectors.
                        groupingBy(Employee::getDepartment,
                                Collectors.counting()))
                .forEach((d, c) -> System.out.println("Dept: " + d + ", Count: " + c));

    }
}